
def search4letters(phrase, letters = 'aeiou'):
    return set(letters).intersection(set(phrase))
