
from setuptools import setup

setup(
    name = 'checker',
    version = '1.0',
    description = 'checker',
    author = 'meep',
    author_email = 'meepmeep@gmail.com',
    url = 'google.com',
    py_modules = ['checker'],
    )
