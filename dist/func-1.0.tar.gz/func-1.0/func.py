
def print_name(num):
    if num == 0:
        return
    print('Seshio')
    return print_name(num - 1)
