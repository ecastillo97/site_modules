
from setuptools import setup

setup(
    name = 'func',
    version = '1.0',
    description = 'recursion',
    author = 'meep',
    author_email = 'meepmeep@gmail.com',
    url = 'google.com',
    py_modules = ['func'],
    )
