from os import getcwd

where_am_I = getcwd()

print (where_am_I)
