
from setuptools import setup

setup(
    name = 'slq',
    version = '1.0',
    description = 'recursion',
    author = 'meep',
    author_email = 'meepmeep@gmail.com',
    url = 'google.com',
    py_modules = ['slq'],
    )
